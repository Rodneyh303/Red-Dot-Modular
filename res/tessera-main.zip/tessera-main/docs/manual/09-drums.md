# 9. Drums

A drum track holds drum sounds in **lanes**: Kick, Snare, Closed hat and so on. Each lane has its own output on the
Drum Out module. Select a drum track and the notes pane shows the **drum editor**. It is the piano roll, with the
lanes on the left instead of the keys.

![The drum editor](images/drum-editor.png)

## The drum editor

- Each row is a lane, in the lanes' own order. Each cell is a step of the lane, 16 to a bar by default. Beats are
  shaded light and dark in turn, so you can count them at a glance.
- A hit sits in its step, filled from the bottom: the higher the fill, the louder the velocity.
- Zoomed far out, the steps are too small for cells and the beats show as bands.
- The lane header shows the lane's name, its output ("→1"), and **M** (mute) and **S** (solo). Muted lanes are dimmed.
- **Click a lane's name** to hear it. **Ctrl+click** it to select all its hits.
- Under the grid, the velocity lane shows the hits of the lane you clicked last. The other lanes' hits are faded.
- **+ Add lane** under the last lane adds a lane.

It zooms and scrolls like the piano roll. **Ctrl+wheel** zooms in time, **=** and **-** zoom in and out, and **F**
fits the clip. You can zoom out past the end of the clip and keep drawing there.

A note on a pitch that no lane plays gets a row of its own under the lanes, marked "(no lane)". It doesn't play.
Move it onto a lane, or delete it.

### Lanes or keys

**Lanes | Keys** in the header switches how the same notes are shown. **G** does the same.

- **Lanes** (the default) is the drum editor described here.
- **Keys** shows them on the piano keys as plain notes, like any piano roll, with all 128 notes. The keys of the
  lanes carry the lanes' names. Use it for free timing, long notes, or notes on no lane.

Zoom, selection and tools carry over when you switch. Roll remembers your choice.

## Making a beat

With the **Draw** tool (D):

- **Click** an empty step to add a hit. **Click** a hit to remove it.
- **Drag** across steps to paint hits. Drag from a hit to remove the hits you pass over.
- **Right-click** or **right-drag** removes hits.
- **Alt+drag** a hit to change its velocity.

A new hit is one step of its lane long, at the last velocity you set. With **Snap Adaptive**, hits land on the lane's
own steps (see **Rate** below), however far you zoom. Pick a fixed snap, like 1/32, to draw finer hits. Hold **Alt**
while you draw to place hits off the grid.

**Draw past the end of the clip** and the clip grows to the end of that bar, in the same undo step. Moving or pasting
hits there does the same. You can also drag the loop end in the ruler, or use the clip chip's lengths.

With the **Select** tool (S), hits work like notes in the piano roll. Click to select, drag to move them in time and
across lanes, **Ctrl+drag** to copy, and drag from empty space to select a box. Drag a hit's edge to change its
length. **Delete** removes the selected hits.

The other tools in the **▾** menu work as in the piano roll. The speaker button turns on **Hear notes while
editing**. Each drag is one undo step.

### Velocity

- **Alt+drag** a hit up or down to change its velocity (Shift for fine steps). If the hit is selected, the whole
  selection changes.
- Or drag across the **velocity lane** under the grid.

### Hit menu

Right-click a hit for its menu. It acts on the selected hits (a hit outside the selection becomes the selection).
Besides the piano roll's note items, it has **Velocity**, **Chance**, **Repeats**, **Only when…** and **Every …
passes**. These are the operators of [Shaping notes](08-shaping-notes.md#operators-notes-that-change-from-pass-to-pass).
With hits selected, the inspector edits them too.

## Pitch, timbre and pressure

Each hit can have its own pitch, timbre and pressure, like a drum machine's per-step tune and tone. They come out
of the Drum Out's **PITCH**, **TIMBRE** and **PRESS** rows. Patch them to a drum module's tune, tone or decay
inputs.

![Hits with pitch values: the stems under the grid, and +2, -2 and +7~ on the cells](images/drum-hit-values.png)

- Choose **Pitch**, **Timbre** or **Pressure** in the lower lane's menu. Each hit gets a stem, as in the velocity
  lane. Drag a stem up or down to give that hit a value. Pitch moves in whole semitones; hold **Shift** for tenths.
- With hits selected, dragging one stem moves them all.
- **Shift+drag** (or the Draw tool) draws values across the stems. **Alt+drag** draws a straight ramp, for a tom
  roll that climbs or hats that get darker across a bar.
- The cells show the values too: **+3** on a tuned hit (a small corner mark when the cell is narrow), and a thin
  bar along the top for timbre and pressure.
- The **±12** button sets how far up and down the lane reaches: ±2 to ±48 semitones.
- The inspector has **Pitch**, **Timbre** and **Pressure** rows for the selected hits, with the same chart as
  velocity. Type a value such as **=+5** or **+2**. On drum tracks the note's own pitch row is called **Note**: it
  picks the lane.

A hit's value holds on the Drum Out until the lane's next hit. A hit with no value sends 0 V there, which means
"as the drum is tuned".

### Shaping a hit's curve

A value can also change across the hit, like a falling tom.

![The curve of one snare hit, zoomed to fill the lane](images/drum-hit-curve.png)

- **Double-click** a stem. The lane zooms onto that hit, so its curve fills the width. Click to add a point, drag
  points to move them, drag a hollow middle handle to arch a segment, and right-click or double-click a point to
  delete it.
- The curve plays across the hit's written length (shown at the right), even on a trigger lane, then holds.
- Click **← Back** or press **Esc** to return to the stems.
- A hit with a curve has a small wave by its stem and **~** after its number on the cell. Dragging its stem moves
  the whole curve and keeps its shape.
- Right-click a stem for **Shape curve…**, **Flatten to one value** and **Clear**.

## Lane settings

Right-click a lane's name for its menu.

![The lane menu with the Euclidean submenu](images/drum-lane-menu.png)

| Item | What it does |
|---|---|
| **Rename** | Also by double-clicking the name. |
| **Colour** | The lane's colour (or the track's). |
| **Note** | The MIDI note this lane plays. A lane plays the clip's notes of this pitch. |
| **Output** | Which Drum Out output (1 to 16) the lane uses. Outputs 1 to 8 have their own jacks; 9 to 16 are on the poly jacks only. Lanes on the same output share it. |
| **Steps** | The lane's own loop length, in steps. "Clip" follows the clip's loop. See [Polymeter](#polymeter). |
| **Rate** | How long a step is for this lane: 1/4 to 1/32, triplets too. |
| **Choke group** | 1 to 8, or none. When a lane in a group plays, it cuts the other lanes of the same group. In the kits, closed and open hats share group 1, so a closed hat cuts a ringing open hat. |
| **Output length** | **Trigger** (1 ms, the default), a gate of a fixed length in milliseconds, or **Note length**: the gate is high for exactly as long as the hit's note, so notes of different lengths sound different. A letter before the output number in the lane header shows the mode: **T** trigger, **G** gate, **N** note length. |

### Pattern tools

Also in the lane menu. Each one is a single undo step. **Euclidean** and **Fill every** clear the lane's old hits
and set its length (its **Steps**) to the pattern's, so the pattern repeats with no seam for the whole clip: Fill
every 3 in a bar of 16 steps hits steps 1, 4, 7, 10, 13 and 16, then keeps counting in threes into the next bar,
instead of hitting step 1 again right after step 16. The other tools work on the lane's steps as they are.

| Tool | What it does |
|---|---|
| **Euclidean** | Pick a number of steps, then a number of hits: the hits are spread as evenly as possible over those steps, and the lane becomes that many steps long. The first step always hits. Great for quick rhythms: 3 hits over 8 steps, 5 over 16… "now" marks the lane's current length. |
| **Rotate left / right** | Shifts the pattern one step. |
| **Reverse** | Plays the pattern backwards. |
| **Fill every** | A hit every 2nd, 3rd, 4th… step: the lane becomes 2, 3, 4… steps long with one hit. |
| **Randomize** | Random steps: 25%, 50% or 75% of them. |
| **Clear** | Clears the lane. |
| **Copy lane / Paste lane** | Copies a lane's steps to another lane. |
| **Add lane / Delete lane** | A drum track has up to 16 lanes. |

## Kits

The **Kit** button in the header loads a set of lanes:

- **Standard 8**: Kick, Snare, Clap, Closed hat, Open hat, Low tom, High tom, Rim. New drum tracks start with it.
- **16 GM-ish**: 16 lanes on General MIDI drum notes.

Loading a kit changes the lanes only. Notes stay, so lanes with the same notes pick them up again.

## Polymeter

A lane can loop on its own length. Set its **Steps** to 12 while the others use 16, and it drifts against the bar,
coming back in line every few bars. The lane's pattern is the first steps of the clip. On the lane's row, a line in
the lane's colour marks where its own loop ends. After it, the row is dimmed and its repeats are faded. It plays the
same way from the clips panel and from the timeline.

In a clip that loops, the loop grows to fit the lanes: it lasts until every lane starts together again. A 1-bar clip
with a 3-step lane loops 3 bars; add a 5-step lane and it loops 15 bars. So every time round sounds the same, and
what you see is what plays:

- The lanes that follow the clip, and notes on no lane, repeat on the clip's length inside the loop. The clip chip
  still shows and sets that length.
- The editor keeps its zoom. Scroll or play along to see the repeats and where the loop ends.
- The loop in the ruler is an outline: it can't be dragged while the lanes set it. Rest the pointer on it to see
  how long it is. You can still turn the loop off.
- Set every lane back to **Steps → Clip** and the loop you had before comes back.

![A 1-bar beat with a 3-step closed hat: the loop runs 3 bars, and the repeats are faded](images/drum-polymeter.png)

A lane with its own length also repeats in a clip that doesn't loop:

- **On the timeline**, it repeats for the whole timeline clip, however far you stretch it. The other lanes play once.
- **In the clips panel**, it repeats until the clip's length. The clip chip shows that length and lets you pick 1 to
  16 bars, as it does for a loop.

Choose **Steps → Clip** to follow the clip's loop again.

## Clip length

The clip chip on the left of the header works as in the piano roll: rename, loop, lengths of 1 to 16 bars,
**Double** (copies the hits into the new half) and **Halve**.

## Wiring the Drum Out

- Each strip is one drum output. Its chip has the lane's colour and number.
- Patch the **TRIG** row to your drum modules' trigger inputs. The light above each strip flashes on a hit.
- The **VEL** row carries each hit's velocity, 0 to 10 V. Patch it to an accent or level input.
- The **PITCH** row carries each hit's tuning, 1 V per octave, 0 V for none. Patch it to a tune input.
- The **TIMBRE** and **PRESS** rows carry each hit's timbre and pressure, 0 to 10 V. Patch them to a tone, decay or
  level input.
- The poly jacks at the bottom carry all 16 outputs, one channel per output. **AUTO** carries the drum track's
  automation lanes.

See [The modules](02-modules.md#drum-out).
