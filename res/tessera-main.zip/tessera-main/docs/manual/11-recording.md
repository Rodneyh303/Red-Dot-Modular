# 11. Recording

You can play notes into Roll from a MIDI keyboard, from CV and gates in your patch, or from your computer keyboard.
Roll records them into clips.

## Where notes come from

| Source | How to set it up |
|---|---|
| **MIDI** | Right-click the Roll panel, **MIDI input (for recording)**, and pick the driver, device and channel. The record button's ▾ menu has the same item. |
| **CV** | Patch the **V/OCT**, **GATE** and (optionally) **VEL** inputs in the panel's lower box. They are polyphonic: each channel is one voice. A note starts when its gate rises above 1 V. If V/OCT moves to another note while the gate stays high (a mono keyboard played legato), that starts a new note too. Without a VEL cable, notes get 80%. |
| **Computer keyboard** | Press **Ctrl+K** in the editor. See [Keyboard play](#keyboard-play). |

## Arming a track

A track records only when it is **armed**.

- Click the **ring** in the track header, or choose **Armed for recording** in the track menu (also in the
  inspector's **Recording** chip). The ring turns red.
- Arming one track disarms the others. **Ctrl+click** arms more than one.

In the track menu (or the inspector's **Recording** chip):

- **Record from**: **Any** (CV and MIDI), **REC CV inputs**, or **MIDI**.
- **MIDI channel**: all channels, or one channel from 1 to 16. So two players on two MIDI channels can record to two
  tracks.
- **Monitor while armed** (on by default): an armed track plays what comes in through its own outputs and devices, so
  you hear yourself.

Arming a track also records its automation lanes: MIDI controls you move, knobs you turn, and CV on the AUTO input.
See [Recording automation](12-automation.md#recording-automation).

To play a track from MIDI or CV all the time, without arming it, set its **Input** instead (see
[Tracks](04-tracks.md#a-track-that-plays-another-track-input)).

## The record button

Press **●** in the transport bar, **REC** on the panel, or **R** in the editor:

- **While stopped:** it counts in (if a count-in is set), then plays and records.
- **While playing:** it starts recording at once ("punch in").
- **While recording:** it stops recording ("punch out"). Playback goes on.

**Stop** also ends recording. Jumping the playhead or pressing reset ends the take and starts a new one.

## Recording settings

Click the **▾** next to the record button.

![The recording settings](images/record-menu.png)

| Setting | Choices |
|---|---|
| **Count-in** | **Off**, **1 bar** or **2 bars**. The record button blinks and the **CLICK** output clicks during the count-in. |
| **New launcher clips** | **As long as played** (rounded up to whole bars when you stop), or a fixed **1, 2, 4 or 8 bars**. A fixed-length clip is finished when full; then it loops and the next passes are added to it. |
| **Recording over arranger clips** | **Merge** (the default: the take is added to the clip that is there), **Stack** (the take is a new clip on top, and the old one stays as it was) or **Replace** (the take replaces what was there). See below. |
| **Input quantize** | **Off**, or a grid from 1/4 to 1/32, with a strength from 50% to 100%. |
| **Snap incoming notes to the key** | Keeps played notes in the song's key, both what you hear and what is recorded. |
| **MIDI controls with no lane** | **Add a lane in the clip** (the default) or **Leave out**. See [Expression and controls](#expression-and-controls). |
| **MPE input** | For a controller that sends MPE (each note on its own channel, with its own bend, slide and pressure). See [Expression and controls](#expression-and-controls). A controller that announces MPE switches this on by itself. |
| **Capture what I just played** | See [Capture](#capture-keep-what-you-just-played). |
| **MIDI input** | The MIDI device. |

## Where the recording goes

It depends on what the armed track is doing when your first note arrives:

- **The track plays a clip from the clips panel:** the new notes are added to that clip. Each time the loop comes
  round, that pass is added (one undo step per pass). You hear the new notes on the next pass.
- **Plays is set to Clips, and the track plays nothing:** a new clip is made in an empty slot (the selected scene's
  slot, or the next empty one). It starts at the bar where recording started, and keeps playing when you punch out.
- **Plays is set to Timeline:** it depends on **Recording over arranger clips**. With the song loop on, each pass is
  its own undo step.
  - **Merge** (the default): what you play goes into the clip that plays at that moment, as if you had drawn it in.
    So you can record the notes first, then go back and record only the mod wheel over them. Nothing new appears
    on the timeline. Where clips are stacked, it goes into the one on top. Where no clip plays, a new clip is made
    for just those notes, from the first to the end of the last. A clip that is placed more than once shares its
    notes, so the new notes show in every copy.
  - **Stack**: a new clip is made from exactly punch-in to punch-out, stacked over what was there. You can
    move, mute or delete each take on its own. Where stacked clips have a lane on the same AUTO channel, the clip on
    top plays it.
  - **Replace**: a new clip is made from exactly punch-in to punch-out, and old clips are cut only there. Notes
    outside that stretch stay, even in the same bar. While you record, the track's timeline clips are silent, so
    you hear only what you play. With Merge and Stack you hear them as you play along.

If you played nothing, nothing is made.

While recording you see it happen: the target slot is red, a clip being added to has a red outline and its new notes
show in red, and timeline takes grow as a red region.

## Expression and controls

Everything you play on a MIDI keyboard is recorded with the notes, in the same take and the same undo step. There is
nothing to set up.

**On each note** (shown in the piano roll's **Pitch**, **Timbre** and **Pressure** curves):

- **Poly aftertouch**: how hard you press each key becomes that note's **Pressure** curve.
- **MPE**: each finger's bend, slide (CC 74) and pressure become the note's **Pitch**, **Timbre** and **Pressure**
  curves. Turn on **MPE input** in the record button's ▾ menu, unless your controller switches it on by itself.

**For the whole track** (automation lanes in the clip the take goes into, made for you):

| You move | Lane | Comes out of |
|---|---|---|
| The pitch bend wheel | **Pitch bend**, ±2 semitones | Added to **V/OCT** on every voice. No cable needed. |
| Channel aftertouch (one pressure for all keys) | **Pressure** | **PRESS** on every voice. Where a note has its own pressure too, the higher one wins. |
| Any other control: mod wheel, sustain pedal, a knob that sends a CC | Named after it, like **Mod wheel (CC 1)** | A free **AUTO** channel, the same one each time for that control |

- Everything a take records goes into its clip: a new clip, the clip you overdub, or the timeline clip it merges
  into. The track gets no lane of its own.
- The exception: a control the track already has its own lane for (one you added under the track) records into that
  track lane, at the song position, unless the clip you overdub has a lane for it.
- Only controls that really move get a lane. A value sent once (the sound change or fader positions some keyboards
  send) leaves nothing behind, and nor do bank select and messages like "all notes off".
- A control that already has a lane in another of the track's clips gets a new lane with the same AUTO channel,
  range and name.
- If all 8 AUTO channels are in use, the control isn't recorded and a message says so.
- **MIDI controls with no lane** in the record button's ▾ menu: **Add a lane in the clip** (the default) or **Leave
  out**. With **Leave out**, only lanes you added (**Add automation lane → MIDI control**) record. A message after
  the take names what was left out, with an **Add lane** button.
- The pitch bend and pressure lanes go back to 0 when no clip plays them, so a track never stays bent.
- The sustain pedal is recorded as a lane that steps on and off. It doesn't make notes longer. Patch its AUTO channel
  to whatever should hold.
- While a track is armed and monitoring, you hear all of this as you play, before and during recording.

## Input quantize and undo

With input quantize on, the recording is first saved as played, then quantized as a second undo step. Press
**Ctrl+Z** once to get your exact timing back.

## Capture: keep what you just played

Roll always listens. When you play something good without recording, press **Capture**: **Ctrl+Shift+R**, or the
record button's ▾ menu.

- Roll keeps the last 64 bars of notes played while not recording.
- Capture turns your last phrase (back to a gap of 4 bars of silence) into a clip on the selected track.
- It keeps what you played on the keys (aftertouch, MPE) and the controls you moved during the phrase (bend, mod
  wheel, pedals, CCs), as a recording does. Each control's lane starts where the control was when the phrase began.
- If you played along with the song, the notes keep their place in the bar. If you played while stopped, the clip
  starts on the beat of the first note.

## Keyboard play

Press **Ctrl+K** in the editor to play notes with your computer keyboard. A banner shows the layout:

- The **A S D F G H J K L** row plays white keys, starting at C.
- The **W E T Y U O P** row plays black keys.
- **Z** and **X** move down and up an octave.
- **C** and **V** make notes softer and louder.
- **Ctrl+K** again turns it off.

While keyboard play is on, the letter keys don't switch tools. Armed tracks play and record the notes, like MIDI. If
the selected track isn't armed, you still hear the notes on it.

## Step input

Step input writes notes one step at a time, without playing in time. Press **Ctrl+R** in the piano roll. A red cursor
appears.

- Play a note (MIDI, REC CV or keyboard play). It is written at the cursor, and the cursor moves one grid step.
- Notes held together are written as a chord on one step.
- **Right arrow** adds a rest. **Shift+Right** makes the last note longer (a tie).
- **Backspace** removes the last step. **Left arrow** steps back.
- **Esc** or **Ctrl+R** ends step input.

The step size is the snap grid. Each note is its own undo step.

## Tips

- Recording records the notes as you played them, before the track's devices. The devices are applied again when it
  plays back, so you can change them later.
- Stopping while recording never leaves a note hanging.
- The record settings and the MIDI device are saved with the patch.
