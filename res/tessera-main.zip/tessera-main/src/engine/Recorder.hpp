#pragma once

#include "../model/AutomationTake.hpp"
#include "../model/Recording.hpp"
#include "Engine.hpp"

#include <deque>
#include <map>
#include <vector>

namespace tessera {

/// What the recorder needs from its Tessera. The module implements it; tests fake it.
class RecorderHost {
  public:
    virtual ~RecorderHost() = default;
    virtual const Song& song() = 0;
    virtual void perform(CommandPtr command) = 0;
    virtual uint64_t nextId() = 0;
    /// Starts a launcher slot at once, in time with a start at `playTick`, so a new clip carries on looping.
    virtual void launchAt(TrackId track, int slot, double playTick) = 0;
    virtual PlayMode playMode() = 0;
    /// The scene whose slot a new launcher clip goes into when that slot is empty.
    virtual int targetScene() = 0;
    /// A take moved CCs it did not record: with no lane while new lanes are off (the editor offers to add them), or
    /// with every AUTO channel of the track in use (`channelsFull`).
    virtual void controlsNotRecorded(TrackId /*track*/, const std::vector<MidiControl>& /*controls*/,
                                     bool /*channelsFull*/) {}
};

/// Turns the engine's record events into song edits on the UI thread (DESIGN.md §14). No Rack dependency.
///
/// Where a take goes, per armed track, decided by its first note:
/// - a track playing a launcher clip overdubs it: each loop pass is merged as it ends;
/// - otherwise in Launcher mode: a new clip in an empty slot, starting at the bar recording started. With a
///   fixed length it is committed when full and then keeps looping, taking overdubs; without one it is as long
///   as the recording, rounded up to the bar;
/// - otherwise in Arranger mode: a new clip on the timeline, one per loop pass.
/// Each commit is one undo step; input quantize is a second one, so undo brings back the played timing.
class Recorder {
  public:
    explicit Recorder(RecorderHost& host) : host(host) {}

    RecordSettings settings;

    void handle(const RecordEvent& event);
    /// Each UI frame: commits loop passes that have ended.
    void update(double playTick);
    bool punchedIn() const { return punched; }

    enum class Target { NewClip, Overdub, Arranger };
    /// Values over time: play ticks for a note's curves, the target's ticks for a control's lane.
    using Samples = TimedValues;
    struct Open {
        double playStart = 0;
        Tick start = 0; // in the target's ticks
        float velocity = 0;
        uint8_t channel = 1;
        Samples pitch, timbre, pressure; // what the key itself played while held
    };
    /// One armed track's take in progress.
    struct Session {
        TrackId track;
        Target target = Target::NewClip;
        ClipId clip; // Overdub
        int slot = kNoSlot;
        double clipStart = 0;       // NewClip, Overdub: the play tick of clip tick 0
        Tick loopLength = 0;        // Overdub: 0 for a clip that doesn't loop
        Tick fixedLength = 0;       // NewClip: 0 = until recording stops
        int64_t pass = 0;           // Overdub: the loop pass the pending notes belong to
        double passFrom = 0;        // Arranger: where this pass started on the timeline
        std::vector<TakeNote> done; // finished notes not yet committed, in the target's ticks
        std::map<int, Open> open;   // held notes by pitch
        // Controls moved and not yet committed, by controlKey(), in the order they first moved: their new lanes
        // take the free AUTO channels in that order, as they did while you heard them.
        std::vector<std::pair<int, Samples>> controls;
        std::vector<std::pair<int, Samples>> songControls; // the same in song ticks, for the track's own lanes
        std::vector<int> reported; // controlKey()s already reported as not recorded, once per recording
        // Knob and AUTO REC lanes recorded in this take: the lane read (as it was) and its pass.
        struct LaneRecording {
            AutomationEnvelope source;
            AutomationTake take;
        };
        std::vector<LaneRecording> lanes;
    };
    const std::vector<Session>& sessions() const { return active; }
    /// Whether a knob or AUTO REC lane is being written now (a mapped knob then follows the hand, not the lane).
    bool laneWriting(AutomationId lane) const;
    /// What the take in progress is writing into a lane, in that lane's ticks, for drawing it live: one list per
    /// stretch of writing.
    std::vector<std::vector<AutoPoint>> liveRuns(LaneOwner owner, const AutomationEnvelope& lane) const;
    /// Where a held note has got to, in its target's ticks, for drawing it live.
    static Tick openLength(const Open& open, double playTick) { return Tick(std::max(1.0, playTick - open.playStart)); }
    /// A MIDI control as a map key, and back.
    static int controlKey(MidiControl c) { return int(c.kind) * 128 + (c.kind == MidiControl::Kind::Cc ? c.cc : 0); }
    static MidiControl controlOfKey(int key) { return {MidiControl::Kind(key / 128), uint8_t(key % 128)}; }

    // Capture: the last notes played while not recording.

    bool canCapture() const { return !buffer.empty(); }
    /// Turns the last phrase played (notes with no gap of `kCaptureGapBars` or more) into a new clip in an
    /// empty slot of `track`. Returns the clip, or an invalid ID when there was nothing or no room.
    ClipId capture(TrackId track);
    static constexpr int kBufferBars = 64;
    static constexpr int kCaptureGapBars = 4;

  private:
    struct Captured {
        double freeStart, playStart, songStart, length;
        bool playing;
        int8_t pitch;
        float velocity, release;
        uint8_t channel = 1;
        Samples pitchCurve, timbre, pressure; // what the key played, on the free clock
    };

    Session* find(TrackId track);
    Session* start(const RecordEvent& event);
    Tick targetTick(const Session& s, const RecordEvent& e) const;
    int64_t passOf(const Session& s, double playTick) const;
    int emptySlot(const Track& track);
    void closeOpen(Session& s, double playTick);
    void commit(Session& s, double endPlay, double endSong, bool final);
    void quantize(ClipId clip, const edits::IdSet& ids);
    /// The same for every clip a take went into, as one undo step.
    void quantize(const std::vector<std::pair<ClipId, edits::IdSet>>& clips);
    void bufferNote(const RecordEvent& event);
    /// A note's pressure, timbre or pitch, or a control, moved while recording.
    void handleValue(const RecordEvent& event);
    /// A reading of a knob or AUTO REC lane's source while recording.
    void handleLaneValue(const RecordEvent& event);
    /// A lane of the track, or of one of its clips, by ID.
    const AutomationEnvelope* findLane(const Track& track, AutomationId id) const;
    /// Overdub ticks (not yet wrapped) wrapped into the clip's loop, split where they wrap.
    static std::vector<std::vector<AutoPoint>> wrapRuns(const Session& s, const std::vector<AutoPoint>& points);
    /// A held note finished at `playTick`, its curves made from what the key played.
    static TakeNote finish(const Open& open, int pitch, double playTick, float release);
    /// The controls moved in a session, as thinned lane points.
    static std::vector<TakeLane> takeLanes(const Session& s);
    /// The controls moved in a session that a lane of the track itself records (and no lane of the clip being
    /// overdubbed), as lanes for recordTrackLanes in song ticks. They leave `s.controls`, so no clip gets them.
    std::vector<TakeLane> trackMidiLanes(Session& s);
    /// Keeps the CCs of `lanes` a take records: those a lane records, and, with new lanes on, those that moved and
    /// find a free AUTO channel. Setup messages never. Tells the host about the rest, except those already in
    /// `reported`, which gains them.
    void filterControls(TrackId track, std::vector<TakeLane>& lanes, std::vector<int>& reported);

    RecorderHost& host;
    bool punched = false;
    double punchPlay = 0, punchSong = 0;
    std::vector<Session> active;

    std::deque<Captured> buffer;
    std::map<int, Captured> bufferOpen;
    /// A control moved while not recording, on the same clocks as the notes, for Capture to turn into lanes.
    struct CapturedValue {
        double freeTick, playTick;
        bool playing;
        int control; // controlKey()
        float value;
    };
    std::deque<CapturedValue> bufferValues;
    /// A held note's pressure, timbre or pitch, or a control, moved while not recording.
    void bufferValue(const RecordEvent& event);
    /// The controls moved between free ticks `from` and `to`, as lanes starting at clip tick `offset`.
    std::vector<TakeLane> capturedLanes(double from, double to, double offset) const;
};

} // namespace tessera
