#pragma once

#include "../../model/DrumKit.hpp"
#include "../EditorContext.hpp"
#include "NoteTarget.hpp"

#include <rack.hpp>

#include <functional>
#include <string>

/// Drum lane operations shared by the drum editor's clicks, menus and keys (DESIGN.md §9), so each exists once.
/// Lanes are addressed by track and lane index; patterns act on the clip the editor shows for the track.
namespace tessera::drumActions {

/// Changes one lane's settings as one undo step.
void editLane(EditorContext& ctx, TrackId track, int lane, const std::function<void(DrumLane&)>& change,
              const std::string& name);
/// Replaces every lane (kit presets, adding and deleting lanes) as one undo step.
void setLanes(EditorContext& ctx, TrackId track, std::vector<DrumLane> lanes, const std::string& name);

/// A pattern tool on one lane: gets the clip's notes, the lane's pitch, region and step length, and returns
/// the new notes. One undo step.
using PatternEdit = std::function<edits::NoteList(const edits::NoteList& notes, int pitch, LaneRegion region, Tick step,
                                                  const edits::IdSource& newId)>;
void editPattern(EditorContext& ctx, TrackId track, int lane, const PatternEdit& edit, const std::string& name);
/// Makes the lane loop on exactly `pattern` (one entry per step, at the lane's rate): its length becomes the
/// pattern's, and its old hits are cleared, so the pattern repeats with no seam (Fill every, Euclidean). One undo
/// step.
void setLanePattern(EditorContext& ctx, TrackId track, int lane, const std::vector<bool>& pattern,
                    const std::string& name);

/// Plays the lane once on the track's outputs.
void audition(EditorContext& ctx, TrackId track, int lane);
/// A new lane after the others, on a note and an output no other lane uses.
void addLane(EditorContext& ctx, TrackId track);

void appendLaneMenu(rack::ui::Menu* menu, EditorContext& ctx, TrackId track, int lane,
                    std::function<void()> startRename);
/// The selected hits' velocity and note operators (chance, repeats, occurrence, recurrence), for a drum track's
/// note menu. It is the way to the operators where the inspector is hidden (the in-panel editor).
void appendHitOperators(rack::ui::Menu* menu, NoteTarget& hits);
/// Kit presets and adding lanes.
void appendKitMenu(rack::ui::Menu* menu, EditorContext& ctx, TrackId track);

} // namespace tessera::drumActions
